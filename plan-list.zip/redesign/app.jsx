// plan-list — redesign shell. Runs fully client-side from window.VAULT (no API).

const { useState, useEffect, useMemo } = React;

// ── View tabs (Preview / Code / Board) ───────────────────────────────────────

function ViewTabs({ mode, onChange }) {
  const tabs = [
    { id: "edit", label: "Documento", icon: <path d="M2 4h12M2 8h12M2 12h8" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" fill="none" /> },
    { id: "markdown", label: "Markdown", icon: <path d="M5 5L2.5 8 5 11M11 5l2.5 3L11 11" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" fill="none" /> },
    { id: "postit", label: "Quadro", icon: <g><rect x="2.5" y="2.5" width="4.5" height="4.5" rx="1" stroke="currentColor" strokeWidth="1.4" fill="none" /><rect x="9" y="2.5" width="4.5" height="4.5" rx="1" stroke="currentColor" strokeWidth="1.4" fill="none" /><rect x="2.5" y="9" width="4.5" height="4.5" rx="1" stroke="currentColor" strokeWidth="1.4" fill="none" /></g> },
  ];
  return (
    <div className="view-tabs" role="tablist">
      {tabs.map((t) => (
        <button key={t.id} role="tab" className={`vt-btn ${mode === t.id ? "is-active" : ""}`} onClick={() => onChange(t.id)}>
          <svg viewBox="0 0 16 16" width="14" height="14">{t.icon}</svg>
          {t.label}
        </button>
      ))}
    </div>
  );
}

// ── Vault picker ──────────────────────────────────────────────────────────────

function VaultPicker({ onOpen }) {
  const [val, setVal] = useState("/home/voce/notas");
  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "100vh", background: "var(--canvas-subtle)" }}>
      <div style={{ background: "var(--canvas)", border: "1px solid var(--border)", borderRadius: "var(--radius-lg)", padding: "36px 40px", boxShadow: "var(--shadow-lg)", display: "flex", flexDirection: "column", gap: "18px", width: "400px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "10px", fontSize: "20px", fontWeight: 600, color: "var(--fg)" }}>
          <svg width="22" height="22" viewBox="0 0 16 16" fill="var(--fg-subtle)"><path d="M2 2.5A2.5 2.5 0 0 1 4.5 0h8.75a.75.75 0 0 1 .75.75v12.5a.75.75 0 0 1-.75.75h-2.5a.75.75 0 0 1 0-1.5h1.75v-2h-8a1 1 0 0 0-.714 1.7.75.75 0 1 1-1.072 1.05A2.495 2.495 0 0 1 2 11.5Zm10.5-1h-8a1 1 0 0 0-1 1v6.708A2.486 2.486 0 0 1 4.5 9h8Z" /></svg>
          plan-list
        </div>
        <div style={{ color: "var(--fg-muted)", fontSize: "14px", lineHeight: 1.5 }}>
          Informe o caminho da pasta com seus arquivos <code style={{ fontFamily: "var(--font-mono)", fontSize: "12px", background: "var(--canvas-inset)", padding: "1px 5px", borderRadius: "4px" }}>.md</code>
        </div>
        <div style={{ display: "flex", gap: "8px" }}>
          <input type="text" value={val} onChange={(e) => setVal(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && val.trim()) onOpen(val.trim()); }}
            style={{ flex: 1, background: "var(--canvas)", border: "1px solid var(--border)", borderRadius: "var(--radius)", padding: "8px 12px", fontSize: "14px", color: "var(--fg)", outline: "none", fontFamily: "var(--font-mono)" }} />
          <button onClick={() => val.trim() && onOpen(val.trim())}
            style={{ background: "var(--success)", color: "#fff", padding: "0 18px", borderRadius: "var(--radius)", fontSize: "13px", fontWeight: 600, border: "none", cursor: "pointer" }}>
            Abrir
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Tweak defaults ────────────────────────────────────────────────────────────

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "aesthetic": "github",
  "density": "confortável",
  "showComments": true
}/*EDITMODE-END*/;

// ── App ───────────────────────────────────────────────────────────────────────

function App() {
  const [tweaks, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [opened, setOpened] = useState(true); // start opened so the redesign shows immediately
  const [vault, setVault] = useState(() => structuredCloneSafe(window.VAULT));
  const [commentsMap, setCommentsMap] = useState(() => buildCommentsMap(window.VAULT));
  const [activeFileId, setActiveFileId] = useState("hoje");
  const [viewMode, setViewMode] = useState("edit");
  const [commentsOpen, setCommentsOpen] = useState(true);
  const [renaming, setRenaming] = useState(false);
  const [renameDraft, setRenameDraft] = useState("");

  useEffect(() => {
    document.documentElement.dataset.aesthetic = tweaks.aesthetic;
    document.documentElement.dataset.density = tweaks.density;
  }, [tweaks.aesthetic, tweaks.density]);

  useEffect(() => { setCommentsOpen(tweaks.showComments); }, [tweaks.showComments]);

  // derive active file + folder
  let file = null, folder = null;
  for (const f of vault.rootFiles) { if (f.id === activeFileId) { file = f; break; } }
  if (!file) {
    for (const fo of vault.folders) {
      const found = fo.files.find((f) => f.id === activeFileId);
      if (found) { file = found; folder = fo; break; }
    }
  }

  const pickFile = (id) => { setActiveFileId(id); setRenaming(false); };

  const handleContentChange = (newContent) => {
    setVault((v) => {
      const patch = (files) => files.map((f) => f.id === activeFileId ? { ...f, content: newContent, updated: "agora" } : f);
      return { ...v, rootFiles: patch(v.rootFiles), folders: v.folders.map((fo) => ({ ...fo, files: patch(fo.files) })) };
    });
  };

  const handleAddComment = (text) => {
    setCommentsMap((m) => ({ ...m, [activeFileId]: [...(m[activeFileId] || []), { id: `c${Date.now()}`, author: "você", when: "agora", text }] }));
  };
  const handleDeleteComment = (cid) => {
    setCommentsMap((m) => ({ ...m, [activeFileId]: (m[activeFileId] || []).filter((c) => c.id !== cid) }));
  };

  const handleNewFile = (dir) => {
    const id = `novo-${Date.now()}`;
    const newFile = { id, name: "Novo documento.md", updated: "agora", content: "# Novo documento\n\n- [ ] primeira task\n" };
    setVault((v) => {
      if (!dir) return { ...v, rootFiles: [newFile, ...v.rootFiles] };
      return { ...v, folders: v.folders.map((fo) => fo.id === dir ? { ...fo, files: [newFile, ...fo.files] } : fo) };
    });
    setActiveFileId(id);
  };

  const commitRename = () => {
    const v = renameDraft.trim() || "Sem título";
    setVault((vault) => {
      const patch = (files) => files.map((f) => f.id === activeFileId ? { ...f, name: `${v}.md` } : f);
      return { ...vault, rootFiles: patch(vault.rootFiles), folders: vault.folders.map((fo) => ({ ...fo, files: patch(fo.files) })) };
    });
    setRenaming(false);
  };

  if (!opened) return <VaultPicker onOpen={() => setOpened(true)} />;

  // progress for header
  const tasks = file ? window.extractTasks(file.content) : [];
  const total = tasks.length;
  const done = tasks.filter((t) => t.done).length;
  const pct = total === 0 ? 0 : Math.round((done / total) * 100);
  const complete = total > 0 && done === total;
  const displayName = file ? file.name.replace(/\.md$/, "") : "";

  return (
    <div className="app-shell">
      <Sidebar
        vault={vault}
        activeFileId={activeFileId}
        onPickFile={pickFile}
        onNewFile={handleNewFile}
        onChangeVault={() => setOpened(false)}
      />

      <main className="main-area">
        {file ? (
          <>
            <div className="file-topbar">
              <div className="breadcrumb">
                <span className="bc-folder">{vault.name}</span>
                <span className="bc-sep">/</span>
                {folder ? (<><span className="bc-folder">{folder.name}</span><span className="bc-sep">/</span></>) : null}
                {renaming ? (
                  <input className="bc-rename-input" autoFocus value={renameDraft}
                    onChange={(e) => setRenameDraft(e.target.value)}
                    onBlur={commitRename}
                    onKeyDown={(e) => { if (e.key === "Enter") commitRename(); else if (e.key === "Escape") setRenaming(false); }} />
                ) : (
                  <span className="bc-file" title="Renomear" onClick={() => { setRenameDraft(displayName); setRenaming(true); }}>{displayName}.md</span>
                )}
              </div>
              <div className="topbar-actions">
                <button className={`btn ${commentsOpen ? "is-active" : ""}`} onClick={() => { const n = !commentsOpen; setCommentsOpen(n); setTweak("showComments", n); }}>
                  <svg width="15" height="15" viewBox="0 0 16 16" fill="currentColor"><path d="M1 2.75C1 1.784 1.784 1 2.75 1h10.5c.966 0 1.75.784 1.75 1.75v7.5A1.75 1.75 0 0 1 13.25 12H9.06l-2.573 2.573A1.458 1.458 0 0 1 4 13.543V12H2.75A1.75 1.75 0 0 1 1 10.25Z" /></svg>
                  <span className="btn-count">{(commentsMap[activeFileId] || []).length}</span>
                </button>
              </div>
            </div>

            <div className="content-scroll">
              <div className="file-canvas">
                <div className="file-box">
                  <div className="file-box-header">
                    <ViewTabs mode={viewMode} onChange={setViewMode} />
                    <div className="file-box-meta">
                      {total > 0 ? (
                        <div className="fb-progress">
                          <div className="fb-progress-bar"><div className="fb-progress-fill" style={{ width: `${pct}%`, background: complete ? "var(--success)" : "var(--done)" }} /></div>
                          <span className="fb-progress-num"><strong>{done}</strong>/{total} · {pct}%</span>
                        </div>
                      ) : (
                        <span className="fb-progress-num">sem tasks</span>
                      )}
                      <span className="fbm-edited">editado {file.updated}</span>
                    </div>
                  </div>

                  {viewMode === "edit" ? (
                    <div className="markdown-body"><Editor content={file.content} onChange={handleContentChange} /></div>
                  ) : viewMode === "markdown" ? (
                    <textarea className="raw-markdown-editor" value={file.content} onChange={(e) => handleContentChange(e.target.value)} spellCheck="false" aria-label="Editar markdown completo" />
                  ) : (
                    <PostItBoard content={file.content} onChange={handleContentChange} />
                  )}
                </div>
              </div>
            </div>
          </>
        ) : (
          <div className="empty-state">
            <svg className="es-glyph" width="40" height="40" viewBox="0 0 16 16" fill="currentColor"><path d="M2 1.75C2 .784 2.784 0 3.75 0h6.586c.464 0 .909.184 1.237.513l2.914 2.914c.329.328.513.773.513 1.237v9.586A1.75 1.75 0 0 1 13.25 16h-9.5A1.75 1.75 0 0 1 2 14.25Z" /></svg>
            <span>Selecione um arquivo</span>
          </div>
        )}
      </main>

      {file && commentsOpen ? (
        <CommentsRail
          comments={commentsMap[activeFileId] || []}
          onAdd={handleAddComment}
          onDelete={handleDeleteComment}
          fileName={file.name}
        />
      ) : null}

      <TweaksPanel title="Tweaks">
        <TweakSection label="Aparência">
          <TweakRadio label="tema" value={tweaks.aesthetic} onChange={(v) => setTweak("aesthetic", v)}
            options={[{ value: "github", label: "Claro" }, { value: "github-dark", label: "Escuro" }]} />
        </TweakSection>
        <TweakSection label="Layout">
          <TweakRadio label="densidade" value={tweaks.density} onChange={(v) => setTweak("density", v)}
            options={[{ value: "compacto", label: "Compacto" }, { value: "confortável", label: "Confortável" }, { value: "espaçoso", label: "Espaçoso" }]} />
          <TweakToggle label="painel de comentários" value={tweaks.showComments} onChange={(v) => setTweak("showComments", v)} />
        </TweakSection>
      </TweaksPanel>
    </div>
  );
}

// ── helpers ───────────────────────────────────────────────────────────────────

function structuredCloneSafe(v) {
  try { return structuredClone(v); } catch { return JSON.parse(JSON.stringify(v)); }
}

function buildCommentsMap(vault) {
  const map = {};
  const add = (f) => { if (f.comments && f.comments.length) map[f.id] = f.comments.map((c) => ({ ...c })); };
  vault.rootFiles.forEach(add);
  vault.folders.forEach((fo) => fo.files.forEach(add));
  return map;
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
